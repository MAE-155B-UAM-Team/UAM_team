from distutils.core import setup


setup(
    name='simple_optimization',
    version='1',
    packages=[
        'simple_optimization',
    ],
    install_requires=[
    ],
)